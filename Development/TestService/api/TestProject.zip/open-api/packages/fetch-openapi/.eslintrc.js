{
  "root": true,
  "ecmaVersion": 6
}
