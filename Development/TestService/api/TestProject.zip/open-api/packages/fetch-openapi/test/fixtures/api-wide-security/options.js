module.exports = {
  preset: 'es6',
};
