module.exports = {
  preset: 'node',
};
