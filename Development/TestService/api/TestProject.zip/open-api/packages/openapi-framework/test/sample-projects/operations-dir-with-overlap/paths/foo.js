module.exports = {
  get: function () {
    return;
  },
};
