module.exports = {
  PUT,
};

function PUT() {
  return;
}

PUT.apiDoc = {
  responses: {
    default: {
      description: 'return foo',
      schema: {},
    },
  },
  tags: ['testing', 'example'],
};
