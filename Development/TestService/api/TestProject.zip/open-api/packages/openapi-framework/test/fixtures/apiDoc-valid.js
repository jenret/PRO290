module.exports = {
  swagger: '2.0',
  info: {
    title: 'sample api doc',
    version: '3',
  },
  paths: {},
};
