module.exports = {
  post: function () {
    return;
  },
};
