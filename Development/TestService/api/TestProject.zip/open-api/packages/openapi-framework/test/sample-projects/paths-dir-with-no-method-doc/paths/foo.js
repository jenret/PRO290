module.exports = {
  GET,
};

function GET() {
  return;
}
