module.exports = {
  parameters: [
    {
      name: 'color',
      in: 'query',
      type: 'string',
    },
  ],
};
