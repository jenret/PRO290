module.exports = {
  getFoo: function getFoo() {
    return;
  },
  postFoo: function getFoo() {
    return;
  },
};
