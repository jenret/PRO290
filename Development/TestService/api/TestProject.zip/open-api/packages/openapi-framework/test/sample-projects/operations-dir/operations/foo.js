module.exports = function getFoo() {
  return;
};
