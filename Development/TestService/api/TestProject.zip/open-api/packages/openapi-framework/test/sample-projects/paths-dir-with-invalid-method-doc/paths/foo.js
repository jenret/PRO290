module.exports = {
  GET,
};

function GET() {
  return;
}
GET.apiDoc = {};
