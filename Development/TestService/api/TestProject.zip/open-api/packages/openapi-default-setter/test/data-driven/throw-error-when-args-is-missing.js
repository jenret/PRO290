module.exports = {
  constructorError: /missing args argument/,

  args: null,

  request: {
    path: '',
    headers: {},
    query: {},
  },

  headers: null,
  params: null,
  query: null,
};
