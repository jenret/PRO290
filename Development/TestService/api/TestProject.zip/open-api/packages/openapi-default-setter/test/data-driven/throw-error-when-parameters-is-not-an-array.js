module.exports = {
  constructorError: /openapi-default-setter: args.parameters must be an Array/,

  args: {
    loggingKey: 'openapi-default-setter',
    parameters: null,
  },

  request: {
    path: '',
    headers: {},
    query: {},
  },

  headers: null,
  params: null,
  query: null,
};
