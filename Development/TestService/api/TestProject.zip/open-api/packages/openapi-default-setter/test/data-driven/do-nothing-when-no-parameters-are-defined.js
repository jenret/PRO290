module.exports = {
  args: {
    parameters: [],
  },

  request: {
    path: '/',
    headers: {},
    query: {},
  },

  headers: null,

  params: null,

  query: null,
};
