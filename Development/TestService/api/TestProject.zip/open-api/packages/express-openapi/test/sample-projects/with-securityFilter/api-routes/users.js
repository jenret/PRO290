module.exports = {
  get: function (req, res, next) {
    return;
  },
};
