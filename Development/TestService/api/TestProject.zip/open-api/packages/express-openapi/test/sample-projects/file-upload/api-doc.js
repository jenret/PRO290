module.exports = {
  swagger: '2.0',

  host: 'test-host',
  basePath: '/v3',

  info: {
    title: 'express-openapi sample project',
    version: '3.0.0',
  },

  definitions: {},

  paths: {},

  tags: [{ description: 'Drafts', name: 'Drafts' }],
};
