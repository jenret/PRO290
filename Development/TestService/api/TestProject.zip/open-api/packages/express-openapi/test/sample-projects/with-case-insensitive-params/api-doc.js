module.exports = {
  swagger: '2.0',
  basePath: '/v1',
  info: {
    title: 'Testing case insensitive params.',
    version: '1.0.0',
  },
  paths: {},
};
